import { useState, useEffect, useRef } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Platform } from 'react-native';
import * as Location from 'expo-location';
import * as DocumentPicker from 'expo-document-picker';
import { Ionicons } from '@expo/vector-icons';
import * as turf from '@turf/turf';
import { DOMParser } from 'xmldom';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

// Web-specific imports
let MapView: any;
let Marker: any;
let Polyline: any;
let Polygon: any;

if (Platform.OS === 'web') {
  const WebMap = () => (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f0f0f0' }}>
      <Text style={{ fontSize: 16, marginBottom: 10 }}>Mapa não disponível na versão web</Text>
      <Text style={{ fontSize: 14, color: '#666' }}>Por favor, use o aplicativo mobile para acessar todas as funcionalidades</Text>
    </View>
  );
  MapView = WebMap;
  Marker = () => null;
  Polyline = () => null;
  Polygon = () => null;
} else {
  const { default: RNMaps, Marker: RNMarker, Polyline: RNPolyline, Polygon: RNPolygon } = require('react-native-maps');
  MapView = RNMaps;
  Marker = RNMarker;
  Polyline = RNPolyline;
  Polygon = RNPolygon;
}

interface Point {
  latitude: number;
  longitude: number;
}

interface ReferenceLine {
  start: Point;
  end: Point;
  bearing: number;
}

export default function MapScreen() {
  const [location, setLocation] = useState<Location.LocationObject | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [polygonCoords, setPolygonCoords] = useState<Point[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [referenceLine, setReferenceLine] = useState<ReferenceLine | null>(null);
  const mapRef = useRef(null);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location);
    })();
  }, []);

  const parseKML = async (fileContent: string) => {
    try {
      const parser = new DOMParser();
      const kml = parser.parseFromString(fileContent, 'text/xml');
      const coordinates = kml.getElementsByTagName('coordinates')[0].textContent;
      
      if (!coordinates) {
        throw new Error('Coordenadas não encontradas no arquivo KML');
      }

      const points = coordinates.trim().split(' ').map(coord => {
        const [lng, lat] = coord.split(',').map(Number);
        return { latitude: lat, longitude: lng };
      });

      if (points.length < 3) {
        throw new Error('O polígono deve ter pelo menos 3 pontos');
      }

      setPolygonCoords(points);
      calculateOptimalReferenceLine(points);
    } catch (error) {
      setErrorMsg('Erro ao processar arquivo KML: ' + (error as Error).message);
    }
  };

  const pickKMLFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/vnd.google-earth.kml+xml',
      });

      if (result.assets && result.assets[0]) {
        const response = await fetch(result.assets[0].uri);
        const text = await response.text();
        await parseKML(text);
      }
    } catch (error) {
      setErrorMsg('Erro ao selecionar arquivo: ' + (error as Error).message);
    }
  };

  const calculateOptimalReferenceLine = (coords: Point[]) => {
    if (coords.length < 3) return;

    try {
      // Convert to turf polygon
      const turfPoints = coords.map(coord => [coord.longitude, coord.latitude]);
      turfPoints.push(turfPoints[0]); // Close the polygon
      const polygon = turf.polygon([turfPoints]);

      // Test different angles to find the optimal one
      let bestAngle = 0;
      let minShortLines = Infinity;
      let bestLine: ReferenceLine | null = null;

      for (let angle = 0; angle < 180; angle += 5) {
        const rotated = turf.transformRotate(polygon, angle);
        const bbox = turf.bbox(rotated);
        const lines = generateParallelLines(bbox, angle, 20); // 20 meters spacing
        
        const shortLines = countShortLines(lines, polygon, 50); // 50 meters threshold
        
        if (shortLines < minShortLines) {
          minShortLines = shortLines;
          bestAngle = angle;
          
          // Calculate reference line
          const center = turf.center(polygon);
          const length = Math.sqrt(
            Math.pow(bbox[2] - bbox[0], 2) + Math.pow(bbox[3] - bbox[1], 2)
          );
          
          const start = turf.destination(center, length/2, bestAngle);
          const end = turf.destination(center, length/2, bestAngle + 180);
          
          bestLine = {
            start: {
              latitude: start.geometry.coordinates[1],
              longitude: start.geometry.coordinates[0]
            },
            end: {
              latitude: end.geometry.coordinates[1],
              longitude: end.geometry.coordinates[0]
            },
            bearing: bestAngle
          };
        }
      }

      if (bestLine) {
        setReferenceLine(bestLine);
      }
    } catch (error) {
      setErrorMsg('Erro ao calcular linha de referência: ' + (error as Error).message);
    }
  };

  const generateParallelLines = (bbox: number[], angle: number, spacing: number) => {
    const lines = [];
    const width = bbox[2] - bbox[0];
    const height = bbox[3] - bbox[1];
    const steps = Math.ceil(Math.max(width, height) / spacing);

    for (let i = 0; i < steps; i++) {
      const line = turf.lineString([
        [bbox[0], bbox[1] + (i * spacing)],
        [bbox[2], bbox[1] + (i * spacing)]
      ]);
      lines.push(turf.transformRotate(line, angle));
    }

    return lines;
  };

  const countShortLines = (lines: any[], polygon: any, threshold: number) => {
    let count = 0;
    for (const line of lines) {
      const intersection = turf.lineIntersect(line, polygon);
      if (intersection.features.length > 0) {
        const length = turf.length(line, { units: 'meters' });
        if (length < threshold) count++;
      }
    }
    return count;
  };

  const handleMapPress = (event: any) => {
    if (!isDrawing) return;

    const newCoord = event.nativeEvent.coordinate;
    setPolygonCoords(prev => [...prev, newCoord]);
  };

  const finishDrawing = () => {
    if (polygonCoords.length < 3) {
      setErrorMsg('Desenhe pelo menos 3 pontos para formar um polígono');
      return;
    }

    setIsDrawing(false);
    calculateOptimalReferenceLine(polygonCoords);
  };

  const MapComponent = Platform.select({
    native: () => (
      <MapView
        ref={mapRef}
        style={styles.map}
        onPress={handleMapPress}
        initialRegion={{
          latitude: location?.coords.latitude ?? -23.5505,
          longitude: location?.coords.longitude ?? -46.6333,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421,
        }}>
        {polygonCoords.length > 0 && (
          <Polygon
            coordinates={polygonCoords}
            fillColor="rgba(43, 87, 151, 0.2)"
            strokeColor="#2b5797"
            strokeWidth={2}
          />
        )}
        {referenceLine && (
          <>
            <Polyline
              coordinates={[referenceLine.start, referenceLine.end]}
              strokeColor="#ff6b35"
              strokeWidth={3}
            />
            <Marker coordinate={referenceLine.start} />
            <Marker coordinate={referenceLine.end} />
          </>
        )}
      </MapView>
    ),
    default: () => <MapView style={styles.map} />,
  });

  return (
    <GestureHandlerRootView style={styles.container}>
      {errorMsg ? (
        <Text style={styles.errorText}>{errorMsg}</Text>
      ) : (
        <>
          {MapComponent()}
          <View style={styles.toolbar}>
            <TouchableOpacity 
              style={styles.button}
              onPress={pickKMLFile}>
              <Ionicons name="document-outline" size={24} color="#2b5797" />
              <Text style={styles.buttonText}>Importar KML</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.button}
              onPress={() => {
                setIsDrawing(!isDrawing);
                if (!isDrawing) {
                  setPolygonCoords([]);
                  setReferenceLine(null);
                } else {
                  finishDrawing();
                }
              }}>
              <Ionicons 
                name={isDrawing ? "checkmark-outline" : "pencil-outline"} 
                size={24} 
                color="#2b5797" 
              />
              <Text style={styles.buttonText}>
                {isDrawing ? 'Finalizar' : 'Desenhar'}
              </Text>
            </TouchableOpacity>
          </View>
          {referenceLine && (
            <View style={styles.resultsContainer}>
              <Text style={styles.resultText}>
                Rumo: {referenceLine.bearing.toFixed(2)}°
              </Text>
              <Text style={styles.resultText}>
                Ponto A: {referenceLine.start.latitude.toFixed(6)}°, {referenceLine.start.longitude.toFixed(6)}°
              </Text>
              <Text style={styles.resultText}>
                Ponto B: {referenceLine.end.latitude.toFixed(6)}°, {referenceLine.end.longitude.toFixed(6)}°
              </Text>
            </View>
          )}
        </>
      )}
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  errorText: {
    fontSize: 16,
    color: '#dc3545',
    textAlign: 'center',
    margin: 20,
  },
  toolbar: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  button: {
    alignItems: 'center',
    padding: 10,
  },
  buttonText: {
    marginTop: 4,
    fontSize: 12,
    color: '#2b5797',
  },
  resultsContainer: {
    position: 'absolute',
    top: 20,
    left: 20,
    right: 20,
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  resultText: {
    fontSize: 14,
    color: '#343a40',
    marginBottom: 5,
  },
});
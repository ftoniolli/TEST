import { StyleSheet, View, Text, TouchableOpacity, Switch } from 'react-native';
import { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';

export default function SettingsScreen() {
  const [useMetric, setUseMetric] = useState(true);
  const [showCompass, setShowCompass] = useState(true);
  const [autoOptimize, setAutoOptimize] = useState(false);

  return (
    <View style={styles.container}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Medidas</Text>
        <View style={styles.setting}>
          <View style={styles.settingInfo}>
            <Ionicons name="ruler-outline" size={24} color="#2b5797" />
            <Text style={styles.settingText}>Usar sistema métrico</Text>
          </View>
          <Switch
            value={useMetric}
            onValueChange={setUseMetric}
            trackColor={{ false: '#767577', true: '#2b5797' }}
            thumbColor="#f4f3f4"
          />
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Navegação</Text>
        <View style={styles.setting}>
          <View style={styles.settingInfo}>
            <Ionicons name="compass-outline" size={24} color="#2b5797" />
            <Text style={styles.settingText}>Mostrar bússola no mapa</Text>
          </View>
          <Switch
            value={showCompass}
            onValueChange={setShowCompass}
            trackColor={{ false: '#767577', true: '#2b5797' }}
            thumbColor="#f4f3f4"
          />
        </View>
        <View style={styles.setting}>
          <View style={styles.settingInfo}>
            <Ionicons name="git-compare-outline" size={24} color="#2b5797" />
            <Text style={styles.settingText}>Otimização automática</Text>
          </View>
          <Switch
            value={autoOptimize}
            onValueChange={setAutoOptimize}
            trackColor={{ false: '#767577', true: '#2b5797' }}
            thumbColor="#f4f3f4"
          />
        </View>
      </View>

      <TouchableOpacity style={styles.helpButton}>
        <Ionicons name="help-circle-outline" size={24} color="#2b5797" />
        <Text style={styles.helpButtonText}>Ajuda e Suporte</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    padding: 20,
  },
  section: {
    marginBottom: 30,
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2b5797',
    marginBottom: 15,
  },
  setting: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingText: {
    marginLeft: 10,
    fontSize: 16,
    color: '#343a40',
  },
  helpButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
  },
  helpButtonText: {
    marginLeft: 10,
    fontSize: 16,
    color: '#2b5797',
    fontWeight: '500',
  },
});
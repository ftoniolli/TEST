import { useState, useEffect } from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { Magnetometer } from 'expo-sensors';
import { Ionicons } from '@expo/vector-icons';

export default function CompassScreen() {
  const [magnetometer, setMagnetometer] = useState(0);
  const [optimalAngle] = useState(45); // Example optimal angle

  useEffect(() => {
    let subscription: any;

    const subscribe = async () => {
      subscription = Magnetometer.addListener(data => {
        let angle = Math.atan2(data.y, data.x) * (180 / Math.PI);
        angle = (angle + 360) % 360;
        setMagnetometer(angle);
      });
    };

    subscribe();

    return () => {
      subscription && subscription.remove();
    };
  }, []);

  const getDirectionText = () => {
    const diff = Math.abs(magnetometer - optimalAngle);
    if (diff <= 5) return 'Direção correta!';
    return diff > 180 ? 'Gire à esquerda' : 'Gire à direita';
  };

  return (
    <View style={styles.container}>
      <View style={styles.compass}>
        <Ionicons
          name="compass"
          size={200}
          color="#2b5797"
          style={[styles.compassIcon, { transform: [{ rotate: `${magnetometer}deg` }] }]}
        />
        <View style={styles.optimalAngle} />
      </View>
      <View style={styles.info}>
        <Text style={styles.angleText}>Ângulo atual: {Math.round(magnetometer)}°</Text>
        <Text style={styles.angleText}>Ângulo ideal: {optimalAngle}°</Text>
        <Text style={styles.directionText}>{getDirectionText()}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f8f9fa',
  },
  compass: {
    width: 250,
    height: 250,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  compassIcon: {
    position: 'absolute',
  },
  optimalAngle: {
    position: 'absolute',
    width: 4,
    height: 120,
    backgroundColor: '#ff6b35',
    transform: [{ rotate: '45deg' }],
  },
  info: {
    marginTop: 40,
    alignItems: 'center',
  },
  angleText: {
    fontSize: 18,
    color: '#2b5797',
    marginVertical: 5,
  },
  directionText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ff6b35',
    marginTop: 20,
  },
});